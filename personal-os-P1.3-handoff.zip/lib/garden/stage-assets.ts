import type { GrowthLevel } from "./types";

/**
 * P1.3 (Personal OS Executive Committee): canonical range is now 0-6.
 *
 * stage-1.webp/stage-2.webp are the ONLY two files with approved canonical
 * status (Seed, Sprout respectively) — unchanged physical files, new
 * canonical keys (0, 1). stage-0.webp remains the transitional Pre-Seed
 * asset (rendered outside this map entirely — see FORMULA.md's Pre-Seed
 * section). stage-3.webp through stage-8.webp remain on disk, untouched,
 * unrenamed, undeleted — but are deliberately NOT wired into this map for
 * canonical levels 2-6, per the artwork gate: a transitional/legacy asset
 * must never be silently presented as final canonical artwork for Young
 * Tree, Growing Tree, Mature Tree, Flourishing Tree, or Ancient Tree.
 *
 * PENDING_ARTWORK is the explicit, named placeholder GardenTile checks
 * for and renders a deliberate provisional state for, rather than either
 * a broken image path or a silent fallback to a wrong-but-numerically-
 * adjacent transitional file.
 */
export const PENDING_ARTWORK = "PENDING_ARTWORK" as const;

export const GARDEN_STAGE_IMAGE: Record<GrowthLevel, string> = {
  0: "/garden/stages/stage-1.webp", // Seed — approved
  1: "/garden/stages/stage-2.webp", // Sprout — approved
  2: PENDING_ARTWORK, // Young Tree — approved artwork not yet available
  3: PENDING_ARTWORK, // Growing Tree — approved artwork not yet available
  4: PENDING_ARTWORK, // Mature Tree — approved artwork not yet available
  5: PENDING_ARTWORK, // Flourishing Tree — approved artwork not yet available
  6: PENDING_ARTWORK, // Ancient Tree — approved artwork not yet available
};

/**
 * Which stage illustrations show visible water (stream/fountain) in the
 * artwork itself. Only meaningful for levels with real approved art
 * (0, 1) — both false, matching stage-1.webp/stage-2.webp's actual
 * content. Pending-artwork levels are false by construction: no shimmer
 * overlay should render on top of a placeholder implying content that
 * does not exist yet. Revisit once each stage's real artwork is approved.
 */
export const GARDEN_STAGE_HAS_WATER: Record<GrowthLevel, boolean> = {
  0: false,
  1: false,
  2: false,
  3: false,
  4: false,
  5: false,
  6: false,
};
