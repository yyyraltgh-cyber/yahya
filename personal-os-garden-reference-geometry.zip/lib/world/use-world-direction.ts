"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { getDirectionSignals, type DirectionSignals } from "@/lib/world/direction";
import { MAX_GROWTH_LEVEL } from "@/lib/garden/types";

const NEUTRAL: DirectionSignals = { pull: 0, intentionality: 0 };
const WINDOW_DAYS = 14;

/**
 * P1.3 (Personal OS Executive Committee): garden_snapshots.growth_level
 * rows written before this date used the prior 0-8 scale; rows on or
 * after it use the canonical 0-6 scale (see lib/garden/FORMULA.md's
 * "Historical scale interpretation" section). No historical row was
 * ever modified, deleted, or reinterpreted — this single named constant
 * is the one place that fact lives, so this hook can normalize each row
 * to a common [0,1] representation, using its own snapshot_date, before
 * averaging. Averaging raw growth_level integers from two different
 * scales together would silently produce a wrong trend the moment both
 * scales appear in the same 14-day window — exactly what would happen
 * without this. This is the actual implementation date, not an estimate.
 */
const GARDEN_SCALE_MIGRATION_CUTOFF = "2026-08-09";
const LEGACY_MAX_GROWTH_LEVEL = 8;

/**
 * Two queries, both against tables that already existed before this
 * release (garden_snapshots since 4B, daily_intentions since the
 * original Niyyah feature) — no new table, no new column, no new write
 * path. Run once per session, same discipline as every other world
 * hook (useWorldHistory, useWorldLegacy).
 */
export function useWorldDirection(userId: string | undefined): DirectionSignals {
  const [signals, setSignals] = useState<DirectionSignals>(NEUTRAL);

  useEffect(() => {
    if (!userId) return;
    let cancelled = false;
    const supabase = createClient();

    const since = new Date();
    since.setDate(since.getDate() - WINDOW_DAYS);
    const sinceDate = since.toISOString().slice(0, 10);

    Promise.all([
      supabase
        .from("garden_snapshots")
        .select("snapshot_date, growth_level")
        .eq("user_id", userId)
        .gte("snapshot_date", sinceDate)
        .order("snapshot_date", { ascending: true }),
      supabase
        .from("daily_intentions")
        .select("id", { count: "exact", head: true })
        .eq("user_id", userId)
        .gte("intention_date", sinceDate),
    ]).then(([snapshotsRes, intentionsRes]) => {
      if (cancelled) return;
      const rows = snapshotsRes.data ?? [];
      const intentionCount = intentionsRes.count ?? 0;

      if (rows.length < 4) {
        // Not enough recorded history yet to derive a trend honestly —
        // stay neutral rather than guess from a couple of points.
        setSignals(NEUTRAL);
        return;
      }

      const mid = Math.floor(rows.length / 2);
      // P1.3: normalize each row individually to [0,1] using its own
      // snapshot_date to pick the correct scale, BEFORE averaging — never
      // averaging raw growth_level values that may span both the legacy
      // 0-8 scale and the canonical 0-6 scale within the same window.
      const normalize = (r: { snapshot_date: string; growth_level: number }) =>
        r.growth_level /
        (r.snapshot_date < GARDEN_SCALE_MIGRATION_CUTOFF ? LEGACY_MAX_GROWTH_LEVEL : MAX_GROWTH_LEVEL);
      const priorAvg = average(rows.slice(0, mid).map(normalize));
      const recentAvg = average(rows.slice(mid).map(normalize));
      // Both averages are already normalized to [0,1] per-row above, so
      // no further division is needed here (previously "/ 8", which
      // assumed every row shared one scale — no longer safe to assume).
      const trendSlope = recentAvg - priorAvg;

      const intentionality = Math.min(1, intentionCount / WINDOW_DAYS);

      setSignals(getDirectionSignals({ trendSlope, intentionality }));
    });

    return () => {
      cancelled = true;
    };
  }, [userId]);

  return signals;
}

function average(values: number[]): number {
  if (values.length === 0) return 0;
  return values.reduce((a, b) => a + b, 0) / values.length;
}
