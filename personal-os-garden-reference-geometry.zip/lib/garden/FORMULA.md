# Garden Growth-Level Formula — Product Spec

*Implemented in `use-garden.ts`. This file is the reviewable source of truth for the*
*decision — the code should link back here, not restate the reasoning inline.*

---

## What this formula decides

A single number, `growthLevel` (0–6), that selects which stage the Garden shows —
Seed, Sprout, Young Tree, Growing Tree, Mature Tree, Flourishing Tree, or Ancient
Tree, per `DESIGN_CONSTITUTION.md` §2. Per the Executive Constitution §6, this number
must represent something *real the user did* — never an arbitrary animation trigger.

**P1.3 migration note:** this scale was previously 0–8 (nine levels). The canonical
model was locked at exactly seven stages, internal range 0–6, in `P1.2-G`/`P1.2-H`,
formally approved for implementation in the P1.3-B executive directive. Every "0–8"
reference below has been replaced; historical data written under the old scale is
handled separately (see "Historical scale interpretation" below), not by reinterpreting
this formula's own current meaning.

## The formula

```
score = habitRatio × 0.4 + achievementRatio × 0.35 + streakFactor × 0.25
growthLevel = round(score × 6), clamped to [0, 6]
```

| Term | Definition | Weight | Why |
|---|---|---|---|
| `habitRatio` | habits completed today ÷ habits scheduled today | **0.40** | The daily, recurring signal — carries the most weight because it's what the user does *most often*, and the Garden's promise is that ordinary daily effort is what grows it. |
| `achievementRatio` | achievements unlocked ÷ achievements total | **0.35** | A slower, cumulative signal — rewards sustained effort over time, not just today, so the Garden doesn't collapse to zero after one quiet day. |
| `streakFactor` | `min(currentStreak / 30, 1)` | **0.25** | Consistency over time. A 30-day streak reaches full weight — a deliberate choice, not derived from another part of the app. |

**The three weights above are unchanged by the P1.3 migration.** Only the discrete
scale the continuous `score` (always mathematically bounded to `[0,1]`, since the
weights sum to exactly `1.0`) is rounded onto changed, from 0–8 to 0–6.

## Pre-Seed — a separate state, not `growthLevel = 0`

`GrowthLevel = 0` means **Seed** — a real, if minimal, first stage of growth.
"Pre-Seed / Not Started" is a distinct product state for a user who has never
recorded a single day of Garden activity, and is deliberately **not** representable
as any `GrowthLevel` value. Determining Pre-Seed requires knowing whether a user has
ever had a `garden_snapshots` row recorded at all — information this formula's
inputs alone cannot answer, since `useGarden()` only ever sees the *current* day's
live ratios.

**Status as of this migration: Pre-Seed detection is not yet wired in.** The existing
`useWorldHistory()` hook (`lib/world/use-world-history.ts`) computes a related
`familiarityFactor` from the same snapshot count this would need, but exposes only a
derived ratio whose loading-state value (`0`, before the async query resolves) is
indistinguishable from a genuine zero-snapshot user's value. Wiring Pre-Seed through
that hook as-is would flash established users into a "Pre-Seed" state on every page
load. This is flagged as an open architectural question for a future, explicitly
authorized change — not silently resolved here.

## Historical scale interpretation

Rows in `garden_snapshots` written before this migration's cutoff date recorded
`growth_level` under the **old 0–8 scale**; rows from the cutoff onward use the
**new 0–6 scale**. Both remain in the same database column, unmodified — no
historical row was rewritten, deleted, or reinterpreted by this migration. The one
confirmed consumer of historical values, `lib/world/use-world-direction.ts`,
normalizes each row to a common `0–1` representation before computing its trend,
using each row's own `snapshot_date` against a single named cutoff constant
(`GARDEN_SCALE_MIGRATION_CUTOFF`, defined in that file) to choose the correct
divisor — `/8` for rows before the cutoff, `/6` (via the same shared
`MAX_GROWTH_LEVEL` constant the live formula uses) for rows on or after it.

The database's own `CHECK (growth_level between 0 and 8)` constraint
(`supabase/migrations/0007_world_memory_foundation.sql`) was deliberately **not**
changed by this migration — `[0,6]` is a strict subset of `[0,8]`, so every future
write already satisfies it, and tightening it before historical data is separately,
explicitly addressed would risk rejecting legitimate old rows. This is a documented,
intentional deferral, not an oversight.

## What is deliberately *not* in the formula (yet)

- **Tasks** — the Today screen currently fetches an overdue-task *count*, not a
  completed-today count. Wiring it in would require a new query, which the original
  brief for this change explicitly disallowed. Left out rather than faked.
- **Goals / long-term projects** — no "goals" data model exists in the current schema.
  The closest concept (`user_journeys`) isn't fetched on the screen that renders the
  Garden.

Both are natural candidates for a future formula revision — but that revision should
update this document first, then the code, not the other way around.

## Changing this formula

Because the weights are a product decision (how much a day "counts" toward what the
user sees), not an engineering detail, any change to the weights, the terms, or the
0–6 scale should:

1. Update this document with the new formula and the reasoning, before or alongside
   the code change.
2. Be checked against Constitution §6 (Garden Philosophy) — specifically that growth
   stays "slow enough to feel earned and honest enough to feel true."
3. Not be a side effect of an unrelated refactor.

## Related, separate decision

`GARDEN_STAGE_HAS_WATER` in `stage-assets.ts` (which stages *visually* show water in
the illustration) is a pure art-asset fact, unrelated to this formula — it does not
affect `growthLevel`, only which decorative shimmer overlay renders on top of it.

