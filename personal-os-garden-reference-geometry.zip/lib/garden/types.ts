/**
 * Garden of Life — shared types.
 * Hybrid architecture: growth stages are static illustrated assets
 * (public/garden/stages/), atmosphere/effects are CSS/SVG layers on top.
 *
 * P1.3 (Personal OS Executive Committee): canonical model locked to exactly
 * seven stages, internal range 0-6, per DESIGN_CONSTITUTION.md §2. This
 * supersedes the prior nine-level (0-8) model permanently. Pre-Seed / Not
 * Started is a separate, non-canonical semantic state and is deliberately
 * NOT representable as a GrowthLevel value — see FORMULA.md.
 */

/** 0 = Seed, 6 = Ancient Tree. One static image per level (or an explicit
 *  pending-artwork placeholder, per stage-assets.ts, for levels without
 *  approved canonical art yet). */
export type GrowthLevel = 0 | 1 | 2 | 3 | 4 | 5 | 6;

/** Single source of truth for the canonical scale's ceiling — every
 *  normalization site (garden-particles.tsx, garden-sky.tsx,
 *  garden-ground.tsx, use-world-direction.ts) imports this rather than
 *  hardcoding its own copy of the number, so a future rescale (should one
 *  ever happen) changes one definition, not four. */
export const MAX_GROWTH_LEVEL: GrowthLevel = 6;

/** Independent of GrowthLevel — layered visually on top of whichever stage
 *  image is showing, never baked into the stage images themselves. */
export type AtmosphereState = "calm" | "recovery" | "celebration" | "night" | "rain";

/** The seven canonical stage names, per DESIGN_CONSTITUTION.md §2. Also the
 *  literal user-facing `alt` text on GardenTile's rendered <Image>
 *  elements — this is accessibility-facing content, not just a label. */
export const GROWTH_STAGE_LABELS: Record<GrowthLevel, string> = {
  0: "Seed",
  1: "Sprout",
  2: "Young Tree",
  3: "Growing Tree",
  4: "Mature Tree",
  5: "Flourishing Tree",
  6: "Ancient Tree",
};

export function clampGrowthLevel(n: number): GrowthLevel {
  return Math.max(0, Math.min(MAX_GROWTH_LEVEL, Math.round(n))) as GrowthLevel;
}

