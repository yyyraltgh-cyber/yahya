import type { GrowthLevel } from "./types";

/**
 * P1.5 (Owner directive): the artwork gate from P1.3 is LIFTED by explicit
 * decision of the project owner. All seven canonical stages now render real
 * isometric artwork from the existing asset set, mapped by visual progression
 * (seed -> sprout -> seedling -> leafy -> water appears -> first flowering
 * tree -> mature formal garden) rather than by filename number.
 *
 * stage-0.webp (empty planter) stays reserved for the Pre-Seed state and is
 * deliberately not part of this canonical map. stage-7.webp remains on disk,
 * unused by the canonical progression, preserved for future use.
 *
 * PENDING_ARTWORK is retained as a safety mechanism only — no canonical
 * level resolves to it any more, but GardenTile still handles it so a future
 * unmapped stage can never render a broken <Image src>.
 */
export const PENDING_ARTWORK = "PENDING_ARTWORK" as const;

export const GARDEN_STAGE_IMAGE: Record<GrowthLevel, string> = {
  0: "/garden/stages/stage-1.webp", // Seed — a single seed in prepared soil
  1: "/garden/stages/stage-2.webp", // Sprout — first two-leaf sprout
  2: "/garden/stages/stage-3.webp", // Young Tree — seedling, moss, stones
  3: "/garden/stages/stage-4.webp", // Growing Tree — fuller leafy growth
  4: "/garden/stages/stage-5.webp", // Mature Tree — larger plant, water arrives
  5: "/garden/stages/stage-6.webp", // Flourishing Tree — flowering canopy, stream
  6: "/garden/stages/stage-8.webp", // Ancient Tree — full formal garden
};

/**
 * Which stage illustrations show visible water (stream/fountain) in the
 * artwork itself — drives the shimmer overlay. Verified by direct visual
 * inspection of each asset: water first appears in stage-5.webp.
 */
export const GARDEN_STAGE_HAS_WATER: Record<GrowthLevel, boolean> = {
  0: false,
  1: false,
  2: false,
  3: false,
  4: true,
  5: true,
  6: true,
};
