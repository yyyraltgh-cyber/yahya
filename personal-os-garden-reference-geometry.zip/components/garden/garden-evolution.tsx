"use client";

import Image from "next/image";
import { GARDEN_STAGE_IMAGE } from "@/lib/garden/stage-assets";
import { GROWTH_STAGE_LABELS, MAX_GROWTH_LEVEL, type GrowthLevel } from "@/lib/garden/types";
import { useGarden } from "@/lib/garden/use-garden";
import { useTranslation } from "@/lib/i18n/locale-context";

/**
 * P1.5 — Garden Evolution strip.
 *
 * A horizontal walk through all seven canonical stages with the user's
 * current stage highlighted. Present in three of the approved visual
 * references (Dashboard, Garden, Statistics) and previously absent from
 * the product entirely — this is the single clearest way the progression
 * itself becomes visible, rather than the user only ever seeing whichever
 * one stage they happen to be on.
 *
 * Computes growthLevel through useGarden itself (pure computation, no
 * query) rather than taking it as a prop — useGarden reads the
 * GamificationProvider context, which is only available inside AppShell,
 * exactly the same reason GardenStage calls it internally too.
 */
export function GardenEvolution({
  habitsDoneToday,
  habitsTotal,
  achievementsUnlocked,
  achievementsTotal,
  hasOverdue,
}: {
  habitsDoneToday: number;
  habitsTotal: number;
  achievementsUnlocked: number;
  achievementsTotal: number;
  hasOverdue: boolean;
}) {
  const { t } = useTranslation();
  const { growthLevel } = useGarden({
    habitsDoneToday,
    habitsTotal,
    achievementsUnlocked,
    achievementsTotal,
    hasOverdue,
  });
  const stages = Array.from({ length: MAX_GROWTH_LEVEL + 1 }, (_, i) => i as GrowthLevel);

  return (
    <section aria-label={t("today.gardenEvolution")}>
      <h3 className="text-section-title">{t("today.gardenEvolution")}</h3>

      <div
        className="-mx-1 flex snap-x snap-mandatory gap-1 overflow-x-auto px-1 pb-2"
        style={{ scrollbarWidth: "none" }}
      >
        {stages.map((level, i) => {
          const isCurrent = level === growthLevel;
          const isReached = level <= growthLevel;

          return (
            <div key={level} className="flex shrink-0 snap-start items-center">
              <div className="flex w-[76px] flex-col items-center gap-1.5">
                <div
                  className={[
                    "relative aspect-square w-full overflow-hidden rounded-[var(--radius-md)] transition-all",
                    isCurrent
                      ? "ring-2 ring-[var(--color-accent)] ring-offset-2 ring-offset-[var(--color-background)]"
                      : "",
                  ].join(" ")}
                  style={{
                    // Stages not yet reached stay visible but recede — the
                    // journey is legible without pretending it's complete.
                    opacity: isReached ? 1 : 0.38,
                    filter: isReached ? undefined : "grayscale(0.55)",
                  }}
                >
                  <Image
                    src={GARDEN_STAGE_IMAGE[level]}
                    alt={GROWTH_STAGE_LABELS[level]}
                    fill
                    sizes="76px"
                    className="object-contain"
                  />
                </div>

                <span
                  className="text-center text-[10px] leading-tight"
                  style={{
                    color: isCurrent ? "var(--color-accent)" : "var(--color-text-muted)",
                    fontWeight: isCurrent ? 600 : 400,
                  }}
                >
                  {GROWTH_STAGE_LABELS[level]}
                </span>
              </div>

              {i < stages.length - 1 && (
                <span
                  aria-hidden="true"
                  className="mx-0.5 mb-4 h-px w-3 shrink-0"
                  style={{
                    backgroundColor: isReached
                      ? "var(--color-accent)"
                      : "var(--color-border)",
                  }}
                />
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}
