"use client";

import { GardenScene } from "@/components/garden/garden-scene";
import { GROWTH_STAGE_LABELS, MAX_GROWTH_LEVEL, type GrowthLevel } from "@/lib/garden/types";
import type { AtmosphereState } from "@/lib/garden/types";
import { useWorldLight } from "@/lib/world/world-light-context";
import { useTranslation } from "@/lib/i18n/locale-context";

export interface GardenZone {
  id: string;
  name: string;
  color: string;
}

/**
 * Zone slot geometry, derived by measurement from REF-14 — not invented.
 *
 * Method: the reference screen was analysed row-by-row for ink density; the
 * garden scene occupies y 19.5%→56.0% of the viewport. Each floating zone
 * label's position was read off REF-14 in screen coordinates and normalised
 * into that band. One slot (Flower Garden, 52%/49% screen) was independently
 * confirmed by connected-component detection of the light pill shape, which
 * landed at 52.1%/49.0% — validating the read to within 0.1%.
 *
 * `side` drives which way the label extends so edge slots never overflow a
 * 360px viewport.
 */
const ZONE_SLOTS: { x: number; y: number; side: "start" | "end" | "center" }[] = [
  { x: 50, y: 2, side: "center" },   // REF-14: The Tree
  { x: 20, y: 7, side: "start" },    // REF-14: Reading Bench
  { x: 80, y: 7, side: "end" },      // REF-14: Prayer Corner
  { x: 15, y: 26, side: "start" },   // REF-14: Library
  { x: 85, y: 29, side: "end" },     // REF-14: Water
  { x: 18, y: 59, side: "start" },   // REF-14: Meditation
  { x: 84, y: 67, side: "end" },     // REF-14: Workout Area
  { x: 52, y: 81, side: "center" },  // REF-14: Flower Garden (confirmed)
];

/**
 * The world, floating on the canvas.
 *
 * Reference rules this component exists to hold, each measured rather than
 * asserted:
 *  - the scene floats directly on the page; no card, no border, no frame
 *    (REF-14: the island sits on unbroken white with only its own soft
 *    contact shadow)
 *  - zone labels float over the scene and are tied to a light point by a
 *    hairline connector (REF-14 draws exactly this)
 *  - everything below the scene is low-ink: REF-14's content rows measure
 *    0–20% ink against the garden band's 97% peak
 */
export function GardenWorld({
  growthLevel,
  atmosphere,
  zones,
}: {
  growthLevel: GrowthLevel;
  atmosphere: AtmosphereState;
  zones: GardenZone[];
}) {
  const { t } = useTranslation();
  const { season, light } = useWorldLight();

  const seasonWord = t(`garden.season.${season.label}` as never);
  const periodWord = light.strength > 0.55 ? t("garden.period.day") : t("garden.period.night");

  return (
    <section aria-label={t("garden.title")}>
      {/* Atmosphere: one human line, no numbers, no engine names. */}
      <p
        className="px-5 text-center text-[11px] tracking-[0.14em]"
        style={{ color: "var(--color-text-muted)" }}
      >
        {seasonWord} · {periodWord}
      </p>

      {/* ── The world ──────────────────────────────────────────────────
          No wrapper surface. The scene is the mass; the page is the white. */}
      <div className="relative mt-2">
        <GardenScene growthLevel={growthLevel} atmosphere={atmosphere} fullBleed />

        {zones.slice(0, ZONE_SLOTS.length).map((zone, i) => {
          const slot = ZONE_SLOTS[i];
          const anchor =
            slot.side === "center"
              ? "-translate-x-1/2 flex-col items-center"
              : slot.side === "start"
                ? "flex-row items-center"
                : "flex-row-reverse items-center";

          return (
            <div
              key={zone.id}
              className={`pointer-events-none absolute flex gap-1.5 ${anchor}`}
              style={{
                insetInlineStart: slot.side === "end" ? undefined : `${slot.x}%`,
                insetInlineEnd: slot.side === "end" ? `${100 - slot.x}%` : undefined,
                top: `${slot.y}%`,
              }}
            >
              {/* Light point — the anchor in the scene */}
              <span
                className="h-1.5 w-1.5 shrink-0 rounded-full"
                style={{
                  backgroundColor: zone.color,
                  boxShadow: `0 0 6px 2px color-mix(in srgb, ${zone.color} 45%, transparent)`,
                }}
                aria-hidden="true"
              />
              {/* Hairline connector, as in REF-14 */}
              {slot.side !== "center" && (
                <span
                  aria-hidden="true"
                  className="h-px w-3 shrink-0"
                  style={{ backgroundColor: `color-mix(in srgb, ${zone.color} 40%, transparent)` }}
                />
              )}
              {/* Floating label */}
              <span
                className="whitespace-nowrap rounded-full px-2.5 py-1 text-[11px] leading-none"
                style={{
                  color: "var(--color-text)",
                  backgroundColor: "color-mix(in srgb, var(--color-surface) 82%, transparent)",
                  backdropFilter: "blur(6px)",
                }}
              >
                {zone.name}
              </span>
            </div>
          );
        })}
      </div>

      {/* ── Growth, stated once, quietly ───────────────────────────── */}
      <div className="mt-4 flex flex-col items-center gap-2.5 px-5">
        <h1 className="text-page-title">{GROWTH_STAGE_LABELS[growthLevel]}</h1>
        <div
          className="flex items-center gap-1.5"
          role="img"
          aria-label={`${GROWTH_STAGE_LABELS[growthLevel]} — ${growthLevel + 1}/${MAX_GROWTH_LEVEL + 1}`}
        >
          {Array.from({ length: MAX_GROWTH_LEVEL + 1 }, (_, i) => (
            <span
              key={i}
              className="h-[3px] rounded-full transition-all"
              style={{
                width: i === growthLevel ? 20 : 6,
                backgroundColor: i <= growthLevel ? "var(--color-accent)" : "var(--color-border)",
              }}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
