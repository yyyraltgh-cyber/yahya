import type { Metadata, Viewport } from "next";
import { Tajawal, Inter } from "next/font/google";
import "./globals.css";
import { ThemeScript } from "@/components/theme-script";
import { ServiceWorkerRegister } from "@/components/sw-register";
import { LocaleProvider } from "@/lib/i18n/locale-context";

// Body/UI face: warm, humanist, highly legible Arabic sans with full Latin
// support for the English toggle. Loaded with Arabic + Latin subsets so
// both locales render correctly without a flash of unstyled/fallback text.
//
// P1.1 note (Personal OS Design Committee): this is now also the sole
// heading/display face for Arabic text — DESIGN_CONSTITUTION.md §13
// forbids Reem Kufi as the primary application heading font, and §4
// locks Tajawal as the single Arabic typeface across every scale tier
// (Large Title through Small Label). Reem Kufi's loader has been
// removed entirely; see P1.1_REEM_KUFI_RESOLUTION_REPORT.md for the
// full before/after of every consumer this affected.
const tajawal = Tajawal({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "700", "900"],
  variable: "--font-tajawal",
  display: "swap",
});

// Canonical Latin typeface (DESIGN_CONSTITUTION.md §4). Loaded in P1.0;
// unchanged by this pass except that it is now also the target for any
// former --font-display consumer rendering Latin text — see
// P1.1_REEM_KUFI_RESOLUTION_REPORT.md.
const inter = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-inter-loader",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Personal OS",
  description: "Your personal operating system for tasks, notes, habits, routines, and more.",
  applicationName: "Personal OS",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Personal OS",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#0E1411",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ar" dir="rtl" className={`${tajawal.variable} ${inter.variable}`}>
      <head>
        <ThemeScript />
      </head>
      <body className="antialiased">
        <LocaleProvider>
          {children}
          <ServiceWorkerRegister />
        </LocaleProvider>
      </body>
    </html>
  );
}
