"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { createClient } from "@/lib/supabase/client";
import { useAuthGuard } from "@/lib/use-auth-guard";
import { useTranslation } from "@/lib/i18n/locale-context";
import { AppShell } from "@/components/layout/app-shell";
import { LoadingScreen } from "@/components/layout/loading-screen";
import { GardenWorld, type GardenZone } from "@/components/garden/garden-world";
import { useGarden } from "@/lib/garden/use-garden";
import { GARDEN_STAGE_IMAGE } from "@/lib/garden/stage-assets";

interface GardenData {
  zones: GardenZone[];
  habitsDoneToday: number;
  habitsTotal: number;
  achievementsUnlocked: number;
  achievementsTotal: number;
  hasOverdue: boolean;
}

/**
 * P1.4 Phase 1 — /garden.
 *
 * The Garden's first existence as a destination rather than a component
 * inside the dashboard. Every number on this screen comes from the user's
 * own rows: life_areas for the zones, habit_logs/habits for today's ratio,
 * user_achievements for the cumulative signal, tasks for the overdue flag.
 * Nothing here is mocked, seeded, or hardcoded.
 *
 * The growth engine (lib/garden) and world engine (lib/world) are consumed
 * exactly as they already exist — this screen adds a surface, not logic.
 */
export default function GardenPage() {
  const { user, loading } = useAuthGuard();
  const { t } = useTranslation();
  const supabase = createClient();
  const [data, setData] = useState<GardenData | null>(null);

  const load = useCallback(async () => {
    if (!user) return;
    const today = new Date().toISOString().slice(0, 10);

    const [areasRes, habitsRes, logsRes, achRes, userAchRes, tasksRes] = await Promise.all([
      supabase
        .from("life_areas")
        .select("id, name, color")
        .eq("user_id", user.id)
        .order("created_at", { ascending: true }),
      supabase.from("habits").select("id").eq("user_id", user.id),
      supabase.from("habit_logs").select("habit_id").eq("user_id", user.id).eq("logged_on", today),
      supabase.from("achievements").select("id"),
      supabase.from("user_achievements").select("achievement_id").eq("user_id", user.id),
      supabase.from("tasks").select("due_date, status").eq("user_id", user.id).neq("status", "done"),
    ]);

    const overdue = (tasksRes.data ?? []).some(
      (row) => row.due_date !== null && row.due_date < today,
    );

    setData({
      zones: areasRes.data ?? [],
      habitsDoneToday: logsRes.data?.length ?? 0,
      habitsTotal: habitsRes.data?.length ?? 0,
      achievementsUnlocked: userAchRes.data?.length ?? 0,
      achievementsTotal: achRes.data?.length ?? 0,
      hasOverdue: overdue,
    });
  }, [supabase, user]);

  useEffect(() => {
    void load();
  }, [load]);

  if (loading || !user) return <LoadingScreen />;

  return (
    <AppShell title={t("garden.title")} userId={user.id}>
      {data === null ? <GardenSkeleton /> : <GardenBody data={data} />}
    </AppShell>
  );
}

/** Quiet placeholder while the user's own rows load — deliberately not the
 *  generic app skeleton, so the first paint already feels like the garden. */
function GardenSkeleton() {
  return (
    <div className="mx-auto w-full max-w-2xl">
      <div
        className="aspect-[4/5] w-full animate-pulse sm:aspect-[16/10]"
        style={{ backgroundColor: "color-mix(in srgb, var(--color-surface-hover) 55%, transparent)" }}
      />
    </div>
  );
}

function GardenBody({ data }: { data: GardenData }) {
  const { t } = useTranslation();
  const { growthLevel, atmosphere } = useGarden({
    habitsDoneToday: data.habitsDoneToday,
    habitsTotal: data.habitsTotal,
    achievementsUnlocked: data.achievementsUnlocked,
    achievementsTotal: data.achievementsTotal,
    hasOverdue: data.hasOverdue,
  });

  // A user with no habits and no achievements has nothing for the growth
  // formula to read — the garden would render at its lowest stage and say
  // nothing. That deserves its own opening moment, not a generic "no data"
  // card: the seed artwork the product already owns, and one line.
  const untouched = data.habitsTotal === 0 && data.achievementsUnlocked === 0;

  if (untouched) {
    return (
      <div className="mx-auto flex w-full max-w-2xl flex-col items-center px-5 pt-6 text-center">
        <div className="relative aspect-square w-full max-w-[280px]">
          <Image
            src={GARDEN_STAGE_IMAGE[0]}
            alt=""
            fill
            sizes="280px"
            className="object-contain"
            priority
          />
        </div>
        <h1 className="text-page-title mt-4">{t("garden.emptyTitle")}</h1>
        <p
          className="mt-2 max-w-xs text-sm leading-relaxed"
          style={{ color: "var(--color-text-muted)" }}
        >
          {t("garden.emptyBody")}
        </p>
      </div>
    );
  }

  return (
    <div className="-mx-6 w-[calc(100%+3rem)] sm:mx-auto sm:w-full sm:max-w-2xl">
      <GardenWorld growthLevel={growthLevel} atmosphere={atmosphere} zones={data.zones} />

      {data.zones.length === 0 && (
        <p
          className="mt-6 px-5 text-center text-xs leading-relaxed"
          style={{ color: "var(--color-text-muted)" }}
        >
          {t("garden.noZones")}
        </p>
      )}
    </div>
  );
}
